<template>
  <button
    class="flex items-center justify-center space-x-1 px-4 py-2 text-xs text-nowrap rounded transition-all duration-300 hover:bg-opacity-75 dark:bg-colorBackground-light bg-colorBackground-dark dark:text-colorText-light text-colorText-dark"
  >
    <slot></slot>
  </button>
</template>
