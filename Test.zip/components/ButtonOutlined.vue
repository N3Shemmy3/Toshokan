<template>
  <button
    class="flex items-center space-x-1 px-4 py-2 rounded text-sm transition-all text-nowrap duration-300 bg-opacity-0 dark:bg-opacity-0 hover:bg-opacity-30 dark:bg-colorBackground-light bg-colorBackground-dark border border-colorText-light/10 dark:border-colorText-dark/10"
  >
    <slot></slot>
  </button>
</template>
