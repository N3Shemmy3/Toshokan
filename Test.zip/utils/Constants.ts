export const BASEURL = "https://shemmynyirenda.icu/api";
