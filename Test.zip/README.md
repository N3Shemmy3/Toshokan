# Toshokan

A simple text based libary written in Nuxt.JS
where users can write books without an account and publish their text
