import{a0 as e,a1 as t}from"./C_3wU3rc.js";const u=e((a,o)=>{if(!localStorage.getItem("user"))return t("/signin")});export{u as default};
